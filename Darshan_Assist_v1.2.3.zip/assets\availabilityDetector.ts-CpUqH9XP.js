(function(){const u=["tickets available","book now","select date","darshan available","slots available","available dates"],c=["sold out","not available","no slots","housefull","tickets exhausted","fully booked"];let d="unknown",r=null;function b(){const e=document.body.innerText.toLowerCase(),t=document.body.innerHTML.toLowerCase(),n=u.some(o=>e.includes(o)||t.includes(o)),i=c.some(o=>e.includes(o)||t.includes(o));return Array.from(document.querySelectorAll('button, input[type="submit"], input[type="button"]')).filter(o=>{const s=(o.textContent||o.value||"").toLowerCase();return(s.includes("book")||s.includes("proceed")||s.includes("continue"))&&!o.disabled}).length>0&&n?"available":i?"sold_out":n?"available":"unknown"}function f(){const e=window.location.href.toLowerCase();return e.includes("darshan")?"₹300 Special Darshan":e.includes("accommodation")?"Accommodation":e.includes("seva")?"Seva Booking":e.includes("srivanitrust")?"Srivani Trust":"Darshan Tickets"}function p(e){const t=document.createElement("div");t.id="da-status-badge";const n={available:{color:"#22C55E",icon:"✅",label:"Tickets Available"},sold_out:{color:"#EF4444",icon:"❌",label:"Sold Out"},unknown:{color:"#6B7280",icon:"⏳",label:"Monitoring..."}},{color:i,icon:l,label:o}=n[e];return t.innerHTML=`
    <div style="
      position:fixed;top:80px;right:16px;z-index:999999;
      background:white;border:2px solid ${i};
      border-radius:12px;padding:10px 16px;
      font-family:'Inter',sans-serif;font-size:13px;font-weight:600;
      box-shadow:0 4px 20px rgba(0,0,0,0.15);
      display:flex;align-items:center;gap:8px;
      animation:fadeIn 0.3s ease-out;
    ">
      <span>${l}</span>
      <div>
        <div style="color:${i};font-size:12px;font-weight:700">${o}</div>
        <div style="color:#888;font-size:11px">Darshan Assist</div>
      </div>
    </div>
  `,t}function v(e){const t=document.getElementById("da-status-badge");t&&t.remove(),r=p(e),document.body.appendChild(r)}function a(){const e=b();if(e!==d&&(d=e,v(e),e==="available")){const t=f();chrome.runtime.sendMessage({type:"AVAILABILITY_DETECTED",payload:{ticketType:t,url:window.location.href}})}}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",a):a();const m=new MutationObserver(()=>{clearTimeout(window._daCheckTimeout),window._daCheckTimeout=setTimeout(a,1500)});m.observe(document.body,{childList:!0,subtree:!0,characterData:!0});setInterval(a,3e4);
})()
