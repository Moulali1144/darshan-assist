(function(){const C=[{keys:["name","full name","pilgrim name","applicant name","devotee name","passenger name"],profileField:"name"},{keys:["dob","date of birth","birth date","birthdate","age"],profileField:"dateOfBirth"},{keys:["gender","sex"],profileField:"gender"},{keys:["mobile","phone","cell","contact number","mobile no"],profileField:"mobile"},{keys:["email","e-mail","mail id","email address"],profileField:"email"},{keys:["address","street","residence","door no","flat"],profileField:"address"},{keys:["city","town","district"],profileField:"city"},{keys:["state","province"],profileField:"state"},{keys:["pincode","pin code","zip","postal code","zipcode"],profileField:"pincode"},{keys:["id number","id no","aadhar","aadhaar","pan","passport number","id proof number"],profileField:"idNumber"},{keys:["id type","id proof type","select id","identity card"],profileField:"idType"}];let p=null;function h(e){var i,d,s;const t=[];e.name&&t.push(e.name.toLowerCase()),e.id&&t.push(e.id.toLowerCase());const n=e.placeholder;n&&t.push(n.toLowerCase()),e.getAttribute("aria-label")&&t.push(e.getAttribute("aria-label").toLowerCase());const r=e.id?document.querySelector(`label[for="${e.id}"]`):e.closest("label")??((i=e.parentElement)==null?void 0:i.querySelector("label"));r&&t.push(((d=r.textContent)==null?void 0:d.toLowerCase().trim())??"");const o=e.closest("td, th, .form-group");return o&&t.push(((s=o.textContent)==null?void 0:s.toLowerCase().trim())??""),t.join(" ")}function L(e){const t=h(e);for(const n of C)if(n.keys.some(r=>t.includes(r)))return n;return null}function u(e,t){let n=0;return e.querySelectorAll('input:not([type="hidden"]):not([type="submit"]):not([type="button"]):not([type="checkbox"]):not([type="radio"]), select').forEach(o=>{var l;if(v(o))return;const i=L(o);if(!i)return;const d=t[i.profileField];if(d==null)return;const s=i.transform?i.transform(String(d)):String(d);if(o.tagName==="SELECT"){const a=o,c=Array.from(a.options).find(g=>g.value.toLowerCase().includes(s.toLowerCase())||g.text.toLowerCase().includes(s.toLowerCase()));c&&(a.value=c.value,a.dispatchEvent(new Event("change",{bubbles:!0})),b(o),n++)}else{const a=o,c=(l=Object.getOwnPropertyDescriptor(window.HTMLInputElement.prototype,"value"))==null?void 0:l.set;c?c.call(a,s):a.value=s,a.dispatchEvent(new Event("input",{bubbles:!0})),a.dispatchEvent(new Event("change",{bubbles:!0})),b(a),n++}}),n}function x(e){if(!e.length)return 0;let t=0;const n=document.querySelectorAll("tr:has(input), .passenger-row, .devotee-row, .pilgrim-card");return n.length>0&&e.length>1?n.forEach((r,o)=>{if(o<e.length){const i=u(r,e[o]);t+=i}}):t=u(document,e[0]),m(),t}function v(e){const t=h(e).toLowerCase();return t.includes("captcha")||t.includes("security code")||t.includes("verif")||e.id.toLowerCase().includes("captcha")||e.name.toLowerCase().includes("captcha")}function m(){setTimeout(()=>{const e=Array.from(document.querySelectorAll('input[type="text"]')).filter(v);if(e.length>0){const t=e[0];t.scrollIntoView({behavior:"smooth",block:"center"}),t.focus(),t.style.outline="3px solid #22C55E",t.style.boxShadow="0 0 15px rgba(34, 197, 94, 0.6)",f("⚡ Form Filled! Cursor is inside CAPTCHA box. Type & hit Enter!","success")}},300)}function b(e){const t=e.style.border;e.style.border="2px solid #C8860A",e.style.background="rgba(200, 134, 10, 0.08)",setTimeout(()=>{e.style.border=t,e.style.background=""},2500)}function w(){const e=document.createElement("div");e.id="da-autofill-btn",e.innerHTML=`
    <div style="
      position: fixed;
      bottom: 24px;
      right: 24px;
      z-index: 999999;
      background: linear-gradient(135deg, #1A0800 0%, #3D1C00 100%);
      border: 1.5px solid #C8860A;
      color: white;
      border-radius: 50px;
      padding: 10px 18px;
      font-family: 'Inter', sans-serif;
      font-size: 13px;
      font-weight: 600;
      cursor: pointer;
      box-shadow: 0 8px 30px rgba(0,0,0,0.5), 0 0 15px rgba(200,134,10,0.4);
      display: flex;
      align-items: center;
      gap: 10px;
      transition: transform 0.2s, box-shadow 0.2s;
      user-select: none;
    " id="da-autofill-inner">
      <span style="font-size:18px">🙏</span>
      <div style="display:flex;flex-direction:column">
        <span style="color:#F59E0B;font-weight:700;font-size:13px">Tatkal Express Fill</span>
        <span style="font-size:10px;color:#AAA">Press Alt + A</span>
      </div>
      <span style="
        background: linear-gradient(135deg, #C8860A, #F59E0B);
        color: white;
        border-radius: 12px;
        padding: 4px 10px;
        font-size: 11px;
        font-weight: 700;
      ">⚡ FILL ALL</span>
    </div>
  `;const t=e.querySelector("#da-autofill-inner");return t.addEventListener("mouseenter",()=>{t.style.transform="translateY(-2px) scale(1.02)",t.style.boxShadow="0 12px 35px rgba(200,134,10,0.6)"}),t.addEventListener("mouseleave",()=>{t.style.transform="",t.style.boxShadow="0 8px 30px rgba(0,0,0,0.5), 0 0 15px rgba(200,134,10,0.4)"}),t.addEventListener("click",E),e}async function E(){chrome.runtime.sendMessage({type:"GET_PILGRIMS"},async e=>{const t=(e==null?void 0:e.pilgrims)||[];if(!t.length){f("⚠️ No family profiles saved. Open Darshan Assist to add pilgrims!","warning");return}const n=x(t);n>0?f(`⚡ Filled ${n} fields for ${t.length} pilgrims!`,"success"):F(t)})}function F(e){var r;const t=document.getElementById("da-pilgrim-selector");t&&t.remove();const n=document.createElement("div");n.id="da-pilgrim-selector",n.innerHTML=`
    <div style="
      position: fixed;
      bottom: 90px;
      right: 24px;
      z-index: 999999;
      background: #1E1E1E;
      border: 1px solid rgba(200,134,10,0.3);
      border-radius: 16px;
      box-shadow: 0 12px 40px rgba(0,0,0,0.6);
      padding: 16px;
      min-width: 280px;
      color: white;
      font-family: 'Inter', sans-serif;
    ">
      <div style="display:flex;justify-content:space-between;align-items:center;margin-bottom:12px">
        <div style="font-weight:700;font-size:13px;color:#F59E0B;">
          🙏 Select Pilgrim
        </div>
        <button id="da-fill-all-btn" style="
          background:linear-gradient(135deg,#C8860A,#F59E0B);
          border:none;color:white;border-radius:8px;padding:4px 8px;
          font-size:11px;font-weight:700;cursor:pointer;
        ">⚡ Fill All (${e.length})</button>
      </div>
      ${e.map(o=>`
        <div class="da-pilgrim-opt" data-id="${o.id}" style="
          padding:10px 12px;
          border-radius:10px;
          cursor:pointer;
          display:flex;
          align-items:center;
          gap:10px;
          margin-bottom:6px;
          transition:background 0.15s;
          border:1px solid rgba(255,255,255,0.08);
          background:rgba(255,255,255,0.03);
        ">
          <div style="
            width:32px;height:32px;border-radius:50%;
            background:linear-gradient(135deg,#C8860A,#F59E0B);
            display:flex;align-items:center;justify-content:center;
            color:white;font-weight:700;font-size:13px;
          ">${o.name.charAt(0).toUpperCase()}</div>
          <div>
            <div style="font-weight:600;font-size:13px;color:#F5F5F0">${o.name}</div>
            <div style="font-size:11px;color:#888">${o.relationship}</div>
          </div>
        </div>
      `).join("")}
    </div>
  `,document.body.appendChild(n),(r=n.querySelector("#da-fill-all-btn"))==null||r.addEventListener("click",()=>{x(e),n.remove()}),n.querySelectorAll(".da-pilgrim-opt").forEach(o=>{const i=o;i.addEventListener("mouseenter",()=>{i.style.background="rgba(200,134,10,0.15)"}),i.addEventListener("mouseleave",()=>{i.style.background="rgba(255,255,255,0.03)"}),i.addEventListener("click",()=>{const d=i.dataset.id,s=e.find(l=>l.id===d);if(s){const l=u(document,s);m(),f(`✅ Filled ${l} fields for ${s.name}`,"success")}n.remove()})}),setTimeout(()=>n==null?void 0:n.remove(),15e3)}function f(e,t){const n=document.getElementById("da-toast");n&&n.remove();const r={success:"#22C55E",warning:"#F59E0B",error:"#EF4444"},o=document.createElement("div");o.id="da-toast",o.style.cssText=`
    position:fixed;top:24px;right:24px;z-index:9999999;
    background:${r[t]};color:white;
    border-radius:12px;padding:12px 20px;
    font-family:'Inter',sans-serif;font-size:13px;font-weight:700;
    box-shadow:0 8px 30px rgba(0,0,0,0.3);
    animation:slideIn 0.3s ease-out;
    max-width:400px;
  `,o.textContent=e,document.body.appendChild(o),setTimeout(()=>o.remove(),4500)}window.addEventListener("keydown",e=>{e.altKey&&(e.key==="a"||e.key==="A")&&(e.preventDefault(),E())});function y(){document.querySelectorAll('form, input:not([type="hidden"])').length>0&&!document.getElementById("da-autofill-btn")&&(p=w(),document.body.appendChild(p))}document.readyState==="loading"?document.addEventListener("DOMContentLoaded",y):y();const k=new MutationObserver(()=>{document.getElementById("da-autofill-btn")||document.querySelectorAll('form, input:not([type="hidden"])').length>0&&(p=w(),document.body.appendChild(p))});k.observe(document.body,{childList:!0,subtree:!0});chrome.runtime.onMessage.addListener((e,t,n)=>{if(e.type==="AUTOFILL_PILGRIM"&&e.payload){const r=u(document,e.payload);m(),n({filledCount:r})}return!0});
})()
